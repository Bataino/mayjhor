function display(){
	var b = document.getElementById("header");
	//var bb = document.getElementById("body");
	b.classList.remove("d-none");
	b.classList.toggle("headerout");
	b.classList.toggle("headerin");
	/*bb.addListener(click,function(){
		b.classList.toggle("headerout");
	b.classList.toggle("headerin");})*/
	/*var call= setInterval(anime,1);
function anime(){
	var b = document.getElementById("header");
	b.style.width = pos+"px";
	pos = pos+5;

}*/
}
function login(){
	var xhtp = new XMLHttpRequest();
	xhtp.open();
}
function showright(name){
	var b = document.getElementById(name);
	//var bb = document.getElementById("body");
	b.classList.remove("d-none");
	b.classList.toggle("headerout");
	b.classList.toggle("headerin");
	}
function cancelheader(){
	var b = document.getElementById("header");
	b.classList.add("d-none");
	}
function show(){
	var click = document.getElementById("tgt");
	var showedd = document.getElementById("tgt_in");
	//var c_v = document.getElementById(checked_value);
	if (click.value == 1) {
		showedd.classList.toggle("d-none");
	}
	else {
		showedd.classList.add("d-none");
	}
}
function show2(){
	var click = document.getElementById("acc");
	var showedd = document.getElementById("acc_in");
	//var c_v = document.getElementById(checked_value);
	if (click.value == 0) {
		showedd.classList.toggle("d-none");
	}
	else {
		showedd.classList.add("d-none");
	}
}
function comment(){
	var b = document.getElementById("commentbox");
	var bb = document.getElementById("body");
	b.classList.remove("d-none");
	b.classList.toggle("commentout");
	b.classList.toggle("commentin");
	bb.classList.toggle("pb-5");
}
function dropdown(name){
	var b = document.getElementById(name);
	b.classList.remove("d-none");
	b.classList.toggle("levelout");
	b.classList.toggle("levelin");
}
function dropdon(name){
	var modal = document.getElementById("myModal");
	var b = document.getElementById(name);
	var bb = document.getElementById("cd");
	var bbb= bb.value;
	if(bbb.length==11){
	b.classList.remove("d-none");
	b.classList.add("levelout");
	}
	else{
		window.alert("Invalid phone");
	}
	modal.style.display = "block";
}
function check(name1,name2){
	var b1 = document.getElementById(name1);
	var b2 = document.getElementById(name2);
	if (b1.classList.contains("levelout")) {
		b1.classList.toggle("levelout");
		b1.classList.toggle("levelin");
	}
	if (b2.classList.contains("levelout")) {
		b2.classList.toggle("levelout");
		b2.classList.toggle("levelin");
	}
}
function alerrt(){
	alt=document.getElementById("message");
	console.log (alt);
}
function cancel(){
	var nxt = document.getElementById("next");
	nxt.removeListener(click);
}
